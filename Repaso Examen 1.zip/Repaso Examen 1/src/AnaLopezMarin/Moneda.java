package AnaLopezMarin;

import java.util.Objects;

public class Moneda {

    //Atributos
    private int año;
    private String pais;
    private String metal;
    private String coda;
    private char grado;
    private double valorCompra;
    private double valorMercado;


    //Constructor con parametros
    public Moneda(int año, String pais, String metal, String coda, char grado, double valorCompra, double valorMercado){
        this.año=año;
        this.pais=pais;
        this.metal=metal;
        this.coda=coda;
        if(grado=='A' || grado=='B' || grado == 'C' || grado == 'D') {
            this.grado = grado;
        }
        if(valorCompra>0) {
            this.valorCompra = valorCompra;
        }
        if(valorMercado>0) {
            this.valorMercado = valorMercado;
        }
    }

    //Sobreescribir constructor por defecto para crear una moneda
    public Moneda(){
        this.año=2022;
        this.pais="España";
        this.metal="Plata";
        this.coda="ES22/7";
        this.grado='A';
        this.valorCompra=100.000;
        this.valorMercado=100.000;
    }

    //Sobreescribir metodo toString
    @Override
    public String toString(){
        return "[" + año + "-" + pais + "-" + metal + "-" + coda + "-" + "Grado: " + grado + "-" + valorCompra + "-" + valorMercado +"]";

    }

    //Sobreescribir metodo equals
    public boolean equals(Object obj){
        if(obj==null)return false;
        if(this==obj) return true;
        if(getClass()!=obj.getClass())return false;
        Moneda moneda = (Moneda) obj;
        return Objects.equals(this.coda,moneda.coda) && Objects.equals(this.grado,moneda.grado);
    }

    //Metodo ganancia para hacer calculo de la moneda
    public double ganancia(){

        return valorMercado-valorCompra;
    }
}
