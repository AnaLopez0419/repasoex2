package AnaLopezMarin;

public class AnaLopezMarin {
    public static void main(String[] args) {
        //Crear 2 monedas por defecto y una personalizada
        Moneda m1 = new Moneda();
        Moneda m2 = new Moneda();
        Moneda m3 = new Moneda(2023, "Francia", "Oro", "4578", 'B', 12.000, 12.000);

        //Crear una coleccion de tamaño 2
        Coleccion c = new Coleccion(2);

        //Mostrar resultado de comparar la moneda 1 y moneda 2
        System.out.println(m1.equals(m2));

        //Añadir monedas a la coleccion
        c.añadeMoneda(m1);
        c.añadeMoneda(m2);
        c.añadeMoneda(m3);

        //Mostrar la coleccion
        System.out.println(c.muestraColeccion());
    }
}
