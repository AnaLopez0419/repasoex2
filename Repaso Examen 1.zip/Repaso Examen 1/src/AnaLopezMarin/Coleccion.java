package AnaLopezMarin;

import java.util.Arrays;

public class Coleccion {

    //Atributos
    private Moneda[] monedas; //array para almacenar elementos de la clase moneda
    private String titular;
    private int tamaño;

    //Constructor que reciba el tamaño.
    public Coleccion(int tamaño){
        if(tamaño < 1) System.out.println("NO");
        else{
            this.tamaño = tamaño;
        }
        this.titular="Ana";
        this.monedas=new Moneda[tamaño];
    }

    //Metodo aumentaTamaño, aumentará en 10 el tamaño de la coleccion
    public void aumentaTamaño(){
        Moneda[] aux = new Moneda[tamaño];
        for(int i=0;i< monedas.length;i++){
            aux[i]=this.monedas[i];
        }
        this.tamaño=this.tamaño+10; //aumento tamaño en 10
        this.monedas=new Moneda[tamaño]; //creo nuevo vector con nuevo tamaño

        for(int j=0;j< aux.length;j++){
            monedas[j]=aux[j];
        }
    }


    //Metodo añadeMoneda, añadirá una moneda a la coleccion.
    //Si está lleno el array llamará antes de añadirla al aumentaTamaño
    public void añadeMoneda(Moneda m){
        int cont=0;
        for(int i=0;i< this.monedas.length;i++){
            if(this.monedas[i]==null){
                cont++;
            }
            if(cont==0){
                aumentaTamaño();
            }
            for(int j=0;j<this.monedas.length;j++){
                if(monedas[j]==null){
                    monedas[j]=m;
                    return;
                }
            }
        }
    }

    //Metodo BeneficioColeccion, devolvera el beneficio total
    //Suma de (ValorMercado-ValorCompra)
    public double beneficioColeccion(){
        double total=0;
        for(int i=0;i< monedas.length;i++){
            total+=monedas[i].ganancia();
        }
        return total;
    }

    //Metodo muestraColeccion, mostrará las monedas de coleccion y el beneficio total
    public String muestraColeccion(){

        return toString()+" Beneficio: "+beneficioColeccion();
    }
    public String toString(){
        return Arrays.toString(monedas);
    }
}
